import calendar
import random
l = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
d1 = dict.fromkeys(l)
print(d1)
