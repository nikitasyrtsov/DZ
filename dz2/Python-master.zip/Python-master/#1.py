x = float(input('vvedite koordinatu x'))
y = float(input('vvedite koordinatu y'))
if (20 - x) + (20 - y) <=10:
  print('to4ka popadaet v krug')
else:
  print('to4ka NE popadaet v krug')