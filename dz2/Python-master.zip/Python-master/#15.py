import calendar
import random
d = {'a':1, 'b':2, 'c':3, 'd':4}
d1 = {'e':5, 'f':6, 'g':7, 'j':8}
d2 = d.update(d1)
print(d)
