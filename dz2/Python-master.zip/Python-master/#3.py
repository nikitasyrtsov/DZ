'''Пользователь вводит число. Проверить вывести является ли число положительным или отрицательным.

'''
x = int(input('vvedite 4islo'))
if  x >= 0:
  print('polozitelnoe')
else:
  print('otritsatelnoe')